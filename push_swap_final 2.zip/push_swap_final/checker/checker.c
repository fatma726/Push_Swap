/*
 * checker/checker.c
 *
 * Entry point for the bonus checker program.  This program reads
 * an initial list of integers from the command line, then
 * processes a sequence of stack operations from standard input.
 * After applying all operations it prints "OK" if stack a is
 * sorted in ascending order and stack b is empty, or "KO"
 * otherwise.  On any invalid input or allocation failure the
 * program calls error_exit(), printing "Error" and terminating.
 */

#include "../includes/parse.h"
#include "../includes/parse_utils.h"
#include "checker_utils.h"
#include "libft.h"
#include <stdlib.h>

/* Execute operations read from standard input */
static void execute_ops(t_stack *a, t_stack *b)
{
    char *line;

    line = read_line();
    while (line)
    {
        apply_op(a, b, line);
        free(line);
        line = read_line();
    }
}

int main(int argc, char **argv)
{
    int     *values;
    int     count;
    t_stack a;
    t_stack b;

    values = NULL;
    count = parse_input(argc, argv, &values);
    if (count <= 0)
    {
        free(values);
        return (0);
    }
    a.data = values;
    a.size = count;
    b.data = (int *)malloc(sizeof(int) * count);
    if (!b.data)
        error_exit();
    b.size = 0;
    execute_ops(&a, &b);
    if (is_sorted(&a) && b.size == 0)
        ft_putendl_fd("OK", 1);
    else
        ft_putendl_fd("KO", 1);
    free(a.data);
    free(b.data);
    return (0);
}