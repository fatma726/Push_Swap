/*
 * checker/swap.c
 *
 * Non‑printing swap operations for the checker program.  These
 * functions mirror the behaviour of the push_swap swap commands
 * (sa, sb, ss) but do not write anything to stdout.  All loops
 * are implemented as while loops and variable declarations are
 * separated from assignments to satisfy the 42 coding standard.
 */

#include "checker_ops.h"

/* Swap the first two elements of a stack without printing */
static void swap_no_print_stack(t_stack *s)
{
    int tmp;

    if (!s || s->size < 2)
        return;
    tmp = s->data[0];
    s->data[0] = s->data[1];
    s->data[1] = tmp;
}

/* sa: swap the first two elements of stack a */
void sa_np(t_stack *a)
{
    swap_no_print_stack(a);
}

/* sb: swap the first two elements of stack b */
void sb_np(t_stack *b)
{
    swap_no_print_stack(b);
}

/* ss: swap the first two elements of both stacks */
void ss_np(t_stack *a, t_stack *b)
{
    swap_no_print_stack(a);
    swap_no_print_stack(b);
}