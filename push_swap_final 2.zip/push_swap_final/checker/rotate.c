/*
 * checker/rotate.c
 *
 * Non‑printing rotation operations for the checker program.  A
 * rotation shifts all elements of a stack up by one position,
 * moving the first element to the last.  The rr_np instruction
 * performs the rotation on both stacks simultaneously.  No
 * operations produce output.  Loops use while statements only.
 */

#include "checker_ops.h"

/* Rotate a stack upwards without printing */
static void rotate_no_print_stack(t_stack *s)
{
    int first;
    int i;

    if (s && s->size > 1)
    {
        first = s->data[0];
        i = 0;
        while (i < s->size - 1)
        {
            s->data[i] = s->data[i + 1];
            i = i + 1;
        }
        s->data[s->size - 1] = first;
    }
}

/* ra: rotate stack a upwards */
void ra_np(t_stack *a)
{
    if (a && a->size > 1)
        rotate_no_print_stack(a);
}

/* rb: rotate stack b upwards */
void rb_np(t_stack *b)
{
    if (b && b->size > 1)
        rotate_no_print_stack(b);
}

/* rr: rotate both stacks upwards */
void rr_np(t_stack *a, t_stack *b)
{
    int executed;

    executed = 0;
    if (a && a->size > 1)
    {
        rotate_no_print_stack(a);
        executed = 1;
    }
    if (b && b->size > 1)
    {
        rotate_no_print_stack(b);
        executed = 1;
    }
    (void)executed;
}