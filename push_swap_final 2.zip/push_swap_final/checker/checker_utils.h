/*
 * checker_utils.h
 *
 * Header for utility functions used by the checker program.  These
 * functions handle reading lines from standard input, comparing
 * strings, and applying operations to the stacks based on user
 * input.  The implementation resides in checker_utils.c.
 */

#ifndef CHECKER_UTILS_H
# define CHECKER_UTILS_H

# include "../includes/stack.h"

/* Read a single line from standard input (excluding the newline).
 * Returns NULL on end of file.  The caller is responsible for
 * freeing the returned string. */
char    *read_line(void);

/* Compare two null‑terminated strings for equality.  Returns 1
 * if the strings are exactly equal or 0 otherwise. */
int     str_equal(char *s1, char *s2);

/* Apply a single operation to the given stacks based on the
 * operation string.  If the operation is invalid, the function
 * invokes error_exit(). */
void    apply_op(t_stack *a, t_stack *b, char *op);

#endif