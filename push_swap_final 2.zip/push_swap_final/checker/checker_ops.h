/*
 * checker_ops.h
 *
 * This header declares the non‑printing stack operations used by the
 * checker bonus program.  Each function performs the same logical
 * operation as its push_swap counterpart but omits any output.  The
 * operations work on the t_stack structure defined in stack.h and
 * assume that the underlying data arrays have sufficient capacity
 * (equal to the total number of input values).  No global
 * variables or macros are used, in accordance with 42 coding
 * standards.
 */

#ifndef CHECKER_OPS_H
# define CHECKER_OPS_H

# include "../includes/stack.h"

/* Swap the first two elements on stack a without printing */
void    sa_np(t_stack *a);
/* Swap the first two elements on stack b without printing */
void    sb_np(t_stack *b);
/* Swap the first two elements of both stacks without printing */
void    ss_np(t_stack *a, t_stack *b);
/* Push the top of b onto a without printing */
void    pa_np(t_stack *a, t_stack *b);
/* Push the top of a onto b without printing */
void    pb_np(t_stack *a, t_stack *b);
/* Rotate stack a upwards without printing */
void    ra_np(t_stack *a);
/* Rotate stack b upwards without printing */
void    rb_np(t_stack *b);
/* Rotate both stacks upwards without printing */
void    rr_np(t_stack *a, t_stack *b);
/* Reverse rotate stack a downwards without printing */
void    rra_np(t_stack *a);
/* Reverse rotate stack b downwards without printing */
void    rrb_np(t_stack *b);
/* Reverse rotate both stacks downwards without printing */
void    rrr_np(t_stack *a, t_stack *b);

#endif