/*
 * checker_utils.c
 *
 * Implements helper functions for the checker program.  These
 * functions include reading a line of input, comparing strings,
 * and applying operations to the stacks.  Memory allocation
 * errors call error_exit(), printing "Error" and terminating the
 * program.  All loops use while statements and variable
 * declarations are separated from assignments.
 */

#include "checker_utils.h"
#include "checker_ops.h"
#include "../includes/parse_utils.h"
#include "libft.h"
#include <unistd.h>
#include <stdlib.h>

/* Append a single character to a dynamically allocated string */
static char *append_char(char *line, char c)
{
    int     len;
    char    *new_line;
    int     i;

    len = 0;
    if (line)
        len = ft_strlen(line);
    new_line = (char *)malloc(sizeof(char) * (len + 2));
    if (!new_line)
        error_exit();
    i = 0;
    while (i < len)
    {
        new_line[i] = line[i];
        i = i + 1;
    }
    new_line[len] = c;
    new_line[len + 1] = '\0';
    if (line)
        free(line);
    return (new_line);
}

/* Read a line from standard input; returns NULL on EOF */
char *read_line(void)
{
    char    *line;
    char    buffer;
    ssize_t bytes;

    line = NULL;
    while (1)
    {
        bytes = read(0, &buffer, 1);
        if (bytes <= 0)
            break;
        if (buffer == '\n')
            break;
        line = append_char(line, buffer);
    }
    if (!line && bytes <= 0)
        return (NULL);
    return (line);
}

/* Compare two strings for equality */
int str_equal(char *s1, char *s2)
{
    int i;

    i = 0;
    if (!s1 || !s2)
        return (0);
    while (s1[i] && s2[i])
    {
        if (s1[i] != s2[i])
            return (0);
        i = i + 1;
    }
    if (s1[i] || s2[i])
        return (0);
    return (1);
}

/* Apply an operation string to the stacks */
void apply_op(t_stack *a, t_stack *b, char *op)
{
    if (!op)
        return;
    if (str_equal(op, "sa"))
        sa_np(a);
    else if (str_equal(op, "sb"))
        sb_np(b);
    else if (str_equal(op, "ss"))
        ss_np(a, b);
    else if (str_equal(op, "pa"))
        pa_np(a, b);
    else if (str_equal(op, "pb"))
        pb_np(a, b);
    else if (str_equal(op, "ra"))
        ra_np(a);
    else if (str_equal(op, "rb"))
        rb_np(b);
    else if (str_equal(op, "rr"))
        rr_np(a, b);
    else if (str_equal(op, "rra"))
        rra_np(a);
    else if (str_equal(op, "rrb"))
        rrb_np(b);
    else if (str_equal(op, "rrr"))
        rrr_np(a, b);
    else
        error_exit();
}