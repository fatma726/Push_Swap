/*
 * checker/reverse_rotate.c
 *
 * Non‑printing reverse rotation operations for the checker program.
 * A reverse rotation shifts all elements of a stack down by one
 * position, moving the last element to the top.  The rrr_np
 * instruction applies the reverse rotation to both stacks.  No
 * output is produced.  All loops are expressed as while loops.
 */

#include "checker_ops.h"

/* Reverse rotate a stack downwards without printing */
static void reverse_rotate_no_print_stack(t_stack *s)
{
    int last;
    int i;

    if (s && s->size > 1)
    {
        last = s->data[s->size - 1];
        i = s->size - 1;
        while (i > 0)
        {
            s->data[i] = s->data[i - 1];
            i = i - 1;
        }
        s->data[0] = last;
    }
}

/* rra: reverse rotate stack a downwards */
void rra_np(t_stack *a)
{
    if (a && a->size > 1)
        reverse_rotate_no_print_stack(a);
}

/* rrb: reverse rotate stack b downwards */
void rrb_np(t_stack *b)
{
    if (b && b->size > 1)
        reverse_rotate_no_print_stack(b);
}

/* rrr: reverse rotate both stacks downwards */
void rrr_np(t_stack *a, t_stack *b)
{
    int executed;

    executed = 0;
    if (a && a->size > 1)
    {
        reverse_rotate_no_print_stack(a);
        executed = 1;
    }
    if (b && b->size > 1)
    {
        reverse_rotate_no_print_stack(b);
        executed = 1;
    }
    (void)executed;
}