/*
 * checker/push.c
 *
 * Non‑printing push operations for the checker program.  Pushing
 * moves the top element from one stack to the other by shifting
 * the destination elements up and the source elements down.  No
 * output is produced.  This implementation assumes that each
 * stack's data array has capacity equal to the total number of
 * input integers, so no dynamic reallocation is required.  All
 * loops use while constructs and comply with the 42 coding style.
 */

#include "checker_ops.h"

/* Transfer the top element from src to dst */
static void push_no_print_stack(t_stack *src, t_stack *dst)
{
    int i;

    if (!src || !dst || src->size == 0)
        return;
    /* Shift elements in dst up to make room */
    i = dst->size;
    while (i > 0)
    {
        dst->data[i] = dst->data[i - 1];
        i = i - 1;
    }
    /* Move top of src to dst */
    dst->data[0] = src->data[0];
    dst->size = dst->size + 1;
    /* Shift elements in src down */
    i = 0;
    while (i < src->size - 1)
    {
        src->data[i] = src->data[i + 1];
        i = i + 1;
    }
    src->size = src->size - 1;
}

/* pa: push the top of stack b onto stack a */
void pa_np(t_stack *a, t_stack *b)
{
    if (b && a && b->size > 0)
        push_no_print_stack(b, a);
}

/* pb: push the top of stack a onto stack b */
void pb_np(t_stack *a, t_stack *b)
{
    if (a && b && a->size > 0)
        push_no_print_stack(a, b);
}